#!/bin/sh


# Log create
rm -rf /data/media/0/Android/EVO/
mkdir /data/media/0/Android/EVO
HENLOG=/data/media/0/Android/EVO/runlogs.txt

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 666 "$1"
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}
echo -e "[$(date +"%Y-%m-%d %T")] Create Read|Write Function.\n" >> $EGLOG

sleep 20

echo -e "[$(date +"%Y-%m-%d %T")] Creating Fstrim Function" >> $EGLOG
function wait_sixty_second() {
sleep 60
}

function get_busybox_dir() {
BUSYBOX=$(find /data/adb/ -type f -name busybox | head -n 1)
}

function set_log_dir() {
LOG=/data/media/0/Android/fstrim.log
}

function get_exec_date() {
DATE=${date}
}

function empty_debug_log() {
echo "" > "$LOG"
}

function run_fstrim_debug() {
$BUSYBOX fstrim -v $1 >> "$LOG"
}

wait_sixty_second
get_busybox_dir
set_log_dir
empty_debug_log
echo -e "[$(date +"%Y-%m-%d %T")] Calling Function" >> $HENLOG

run_fstrim_debug /system
run_fstrim_debug /vendor
run_fstrim_debug /metadata
run_fstrim_debug /odm
run_fstrim_debug /system_ext
run_fstrim_debug /data
run_fstrim_debug /cache
echo -e "[$(date +"%Y-%m-%d %T")] Fstrim Done \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Turning off Printk" >> $HENLOG
write_file_lock "/proc/sys/kernel/printk" "0 0 0 0"
write_file_lock "/proc/sys/kernel/printk_devkmsg" "off"
write_file_lock "/sys/module/printk/parameters/console_suspend" "Y"
write_file_lock "/sys/module/printk/parameters/cpu" "N"
write_file_lock "/sys/module/printk/parameters/ignore_loglevel" "Y"
write_file_lock "/sys/module/printk/parameters/pid" "N"
write_file_lock "/sys/module/printk/parameters/time" "N"
write_file_lock "/sys/kernel/printk_mode/printk_mode" "0"
echo -e "[$(date +"%Y-%m-%d %T")] Disabled printk on \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Turning off panic" >> $HENLOG
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom
echo -e "[$(date +"%Y-%m-%d %T")] Disabled panic \n" >> $HENLOG

write_file_lock "/proc/sys/vm/drop_caches" "3"
write_file_lock "/proc/sys/vm/dirty_background_ratio" "11"
write_file_lock "/proc/sys/vm/dirty_expire_centisecs" "400"
write_file_lock "/proc/sys/vm/page-cluster" "0"
write_file_lock "/proc/sys/vm/dirty_ratio" "20"
write_file_lock "/proc/sys/vm/laptop_mode" "0"
write_file_lock "/proc/sys/vm/block_dump" "0"
write_file_lock "/proc/sys/vm/compact_memory" "1"
write_file_lock "/proc/sys/vm/dirty_writeback_centisecs" "3000"
write_file_lock "/proc/sys/vm/oom_dump_tasks" "0"
write_file_lock "/proc/sys/vm/oom_kill_allocating_task" "0"
write_file_lock "/proc/sys/vm/stat_interval" "1103"
write_file_lock "/proc/sys/vm/panic_on_oom" "0"
write_file_lock "/proc/sys/vm/swappiness" "60"
write_file_lock "/proc/sys/vm/vfs_cache_pressure" "94"
write_file_lock "/proc/sys/vm/overcommit_ratio" "50"
write_file_lock "/proc/sys/vm/extra_free_kbytes" "24300"
write_file_lock "/proc/sys/kernel/random/read_wakeup_threshold" "64"
write_file_lock "/proc/sys/kernel/random/write_wakeup_threshold"
echo -e "[$(date +"%Y-%m-%d %T")] Performance Tweaks" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Tweaking cpu, gpu|adreno " >> $EGLOG
write_file_lock /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpufreq/policy0/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpufreq/policy4/scaling_governor performance
write_file_lock /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write_file_lock /sys/devices/system/cpu/cpufreq/performance/boost 1
write_file_lock /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 100
write_file_lock /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write_file_lock /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write_file_lock /sys/kernel/gpu/gpu_governor performance
write_file_lock /sys/module/adreno_idler/parameters/adreno_idler_active 0
write_file_lock /sys/module/lazyplug/parameters/nr_possible_cores 8
write_file_lock /sys/module/msm_performance/parameters/touchboost 1
write_file_lock /dev/cpuset/foreground/boost/cpus 4-7
write_file_lock /dev/cpuset/foreground/cpus 0-3,4-7
write_file_lock /dev/cpuset/top-app/cpus 0-7
echo -e "[$(date +"%Y-%m-%d %T")] Tweaked Performance\n" >> $HENLOG


echo -e "[$(date +"%Y-%m-%d %T")] Turning off printk" >> $HENLOG
write_file_lock "/proc/sys/kernel/printk" "0 0 0 0"
write_file_lock "/proc/sys/kernel/printk_devkmsg" "off"
write_file_lock "/sys/module/printk/parameters/console_suspend" "Y"
write_file_lock "/sys/module/printk/parameters/cpu" "N"
write_file_lock "/sys/module/printk/parameters/ignore_loglevel" "Y"
write_file_lock "/sys/module/printk/parameters/pid" "N"
write_file_lock "/sys/module/printk/parameters/time" "N"
write_file_lock "/sys/kernel/printk_mode/printk_mode" "0"
echo -e "[$(date +"%Y-%m-%d %T")] Disabled printk \n" >> $HENLOG


chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable
echo -e "[$(date +"%Y-%m-%d %T")] Disable Fsync \n" >> $HENLOG

echo 0 >/sys/fs/selinux/log/deny_unknown
echo -e "[$(date +"%Y-%m-%d %T")] no logs selinux" >> $HENLOG

echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable
echo -e "[$(date +"%Y-%m-%d %T")] I/O Tweaked \n" >> $HENLOG

echo 100 > /sys/module/cpu_boost/parameters/input_boost_ms
echo 0-7 > /dev/cpuset/top-app/cpus
echo 0-7 > /dev/cpuset/game/cpus
echo 0-7 > /dev/cpuset/gamelite/cpus
echo "2-3,6-7" > /dev/cpuset/foreground/cpus
echo 2-3 > /dev/cpuset/background/cpus
echo 0-1 > /dev/cpuset/system-background/cpus

echo 1 > /dev/stune/top-app/schedtune.colocate
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled
echo 1 > /dev/stune/top-app/schedtune.sched_boost_no_override
echo 0 > /dev/stune/top-app/schedtune.prefer_idle
echo 0 > /dev/stune/top-app/schedtune.boost
echo 0 > /dev/stune/foreground/schedtune.colocate
echo 1 > /dev/stune/foreground/schedtune.sched_boost_enabled
echo 0 > /dev/stune/foreground/schedtune.sched_boost_no_override
echo 0 > /dev/stune/foreground/schedtune.prefer_idle
echo 0 > /dev/stune/foreground/schedtune.boost
echo 0 > /dev/stune/background/schedtune.colocate
echo 1 > /dev/stune/background/schedtune.sched_boost_enabled
echo 0 > /dev/stune/background/schedtune.sched_boost_no_override
echo 0 > /dev/stune/background/schedtune.prefer_idle
echo 0 > /dev/stune/background/schedtune.boost
echo 0 > /dev/stune/schedtune.colocate
echo 1 > /dev/stune/schedtune.sched_boost_enabled
echo 0 > /dev/stune/schedtune.sched_boost_no_override
echo 0 > /dev/stune/schedtune.prefer_idle
echo 0 > /dev/stune/schedtune.boost
echo -e "[$(date +"%Y-%m-%d %T")] CPU Sets Tuning \n" >> $HENLOG

echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo -e "[$(date +"%Y-%m-%d %T")] Memory Tuning Active \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Disabling Timer Migration \n" >> $HENLOG
echo 0 > /proc/sys/kernel/timer_migration
echo -e "[$(date +"%Y-%m-%d %T")] Done \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] Applying tweak perf cpu time max percent \n" >> $HENLOG
echo 50 > /proc/sys/kernel/perf_cpu_time_max_percent
echo -e "[$(date +"%Y-%m-%d %T")] Done \n" >> $HENLOG

echo -e "[$(date +"%Y-%m-%d %T")] All Done!" >> $HENLOG