SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

ui_print ""
ui_print "
╔═══╗─────╔╗───╔╗────────╔═══╗
║╔══╝─────║║──╔╝╚╗───────║╔═╗║
║╚══╦╗╔╦══╣║╔╗╠╗╔╬╦══╦═╗─║║─╚╝
║╔══╣╚╝║╔╗║║║║║║║╠╣╔╗║╔╗╗║║╔═╗
║╚══╬╗╔╣╚╝║╚╣╚╝║╚╣║╚╝║║║║║╚╩═║
╚═══╝╚╝╚══╩═╩══╩═╩╩══╩╝╚╝╚═══╝
"
ui_print " EVOLUTION G [Gaming] " 
ui_print " VERSION : 1.0 BETA "
ui_print ""
ui_print ""
ui_print " [Log]> Turning On Gaming "
ui_print " [Log]> Evolution Gaming Active "
ui_print ""
ui_print ""
ui_print " Done "